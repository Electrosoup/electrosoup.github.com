# make these easier to import
from meld3 import parse_xml
from meld3 import parse_html
from meld3 import parse_xmlstring
from meld3 import parse_htmlstring
