def test_suite():
    return unittest.findTestCases(sys.modules[__name__])
