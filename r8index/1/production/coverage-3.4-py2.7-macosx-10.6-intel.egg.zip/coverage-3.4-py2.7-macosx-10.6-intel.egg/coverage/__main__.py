"""Coverage.py's main entrypoint."""
from coverage.cmdline import main
main()
