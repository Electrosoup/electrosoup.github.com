# this is a package

from ZODB.FileStorage.FileStorage import FileStorage, TransactionRecord
from ZODB.FileStorage.FileStorage import FileIterator, Record, packed_version


# BBB Alias for compatibility
RecordIterator = TransactionRecord
