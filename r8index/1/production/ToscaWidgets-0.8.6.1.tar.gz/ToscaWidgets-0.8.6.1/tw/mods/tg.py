from inspect import isclass
from pkg_resources import require
require("TurboGears>=1.0")

import os, logging, new, threading

from paste.registry import Registry
import turbogears, cherrypy
from cherrypy.filters.basefilter import BaseFilter
from turbogears.i18n.tg_gettext import gettext
from turbogears import util as tg_util
from turbogears.view import stdvars

import tw
from tw.core import view
from tw.mods.base import HostFramework
from tw.core.util import RequestLocalDescriptor, install_framework

install_framework()

PREFIX = '/toscawidgets'

log = logging.getLogger(__name__)

_first_call_lock = threading.Lock()
_has_registered = False
def url_wrapper(self, url):
    # On first call, register all static directories and delete the 
    # instance method so subsequent calls hit the original class method with
    # no thread lock overhead
    _first_call_lock.acquire()
    try:
        global _has_registered
        if not _has_registered:
            # Preload tg.include_widgets so they get registered
            for widget in turbogears.config.get("toscawidgets.include_widgets", []):
                widget = tg_util.load_class(widget)  
                if isclass(widget):
                    widget = widget()

            from  tw.core.resources import registry
            for webpath, dir in registry.get_prefixed():
                #XXX: the commented line produces wrong paths when TG app
                #     not mounted at root. See http://trac.turbogears.org/ticket/1403
                #webpath = self.__class__.url(webpath)
                webpath = PREFIX + webpath
                log.info("Registering static directory %r at %r", dir, webpath)
                self._register_static_directory(webpath, dir)
            del self.url
            _has_registered = True
    finally:
        _first_call_lock.release()
    return self.__class__.url(url)


class Turbogears(HostFramework):

    @staticmethod
    def url(url):
        return turbogears.url(PREFIX + url)


    def _register_static_directory(self, webpath, directory):
        """
        Registers the given filesystem's directory to be accesible from
        the web"""
        directory = os.path.abspath(directory)

        turbogears.config.update({
            webpath: {
                'static_filter.on' : True,
                'static_filter.dir' : directory
                }
            })

def _extract_config():
    from cherrypy.config import configs
    c = configs.get('global', {}).copy()
    c.update(configs['/'])
    return c

class TWInitFilter(BaseFilter):
    """Sort-of-emulates TWWidgetsMiddleware + Paste's RegsitryManager. Takes
    care of preparing the hostframework for a request."""

    def __init__(self, host_framework):
        self.host_framework = host_framework

    def on_start_resource(self):
        log.debug("TWFilter: on_start_resource")
        environ = cherrypy.request.wsgi_environ
        registry = environ.setdefault('paste.registry', Registry())
        registry.prepare()
        registry.register(tw.framework, self.host_framework)
        self.host_framework.start_request(environ)
    def on_end_resource(self):
        log.debug("TWFilter: on_end_resource")
        try:
            environ = cherrypy.request.wsgi_environ
            self.host_framework.end_request(environ)
        finally:
            registry = environ['paste.registry']
            registry.cleanup()

def start_extension():
    if turbogears.config.get('toscawidgets.on', False):
        engines = view.EngineManager()
        engines.load_all(_extract_config(), stdvars)
        host_framework = Turbogears(
            engines = engines,
            default_view = turbogears.config.get('tg.defaultview', 'kid'),
            translator = gettext,
            )
        host_framework.url = new.instancemethod(
            url_wrapper, host_framework, Turbogears)
        log.info("Loaded TurboGears HostFramework")
        cherrypy.root._cp_filters.append(TWInitFilter(host_framework))
        log.info("Added TWInitFilter")
