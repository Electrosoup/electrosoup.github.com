from urllib import unquote

import pkg_resources

from paste.cascade import Cascade
from paste.urlmap import URLMap
from paste.request import path_info_pop, path_info_split
from paste.deploy.converters import asbool
from paste.registry import RegistryManager

import tw
from tw.mods import base
from tw.core import feeder, resources

    
class ToscaWidgetsMiddleware(object):
    def __init__(self, application, host_framework, prefix='/toscawidgets',
                 show_apache_config=None, inject_resources=False):
        self.host_framework = host_framework
        self.prefix = prefix

        self.tw_apps = URLMap()
        self.tw_apps[feeder.registry.prefix] = feeder.registry
        self.tw_apps[resources.registry.prefix] = resources.registry
        self.application = application

        if show_apache_config is not None:
            import warnings
            warnings.warn("'show_apache_config' is deprecated, will have no "
                          "effect", DeprecationWarning, 2)

        if inject_resources:
            from tw.core.resource_injector import injector_middleware
            self.application = injector_middleware(self.application)

        self.wsgi_app = RegistryManager(self.wsgi_app)

    def __call__(self, environ, start_response):
        return self.wsgi_app(environ, start_response)

    def wsgi_app(self, environ, start_response):
        self.host_framework.start_request(environ)
        environ['toscawidgets.prefix'] = self.prefix
        environ['paste.registry'].register(tw.framework,
                                           self.host_framework)
        environ.setdefault('toscawidgets.framework', self.host_framework)

        path_info = environ.get('PATH_INFO', '')
        try:
            if path_info.startswith(self.prefix):
                path_info_pop(environ)
                app_iter = self.tw_apps(environ, start_response)
            else:
                app_iter = self.application(environ, start_response)
        finally:
            self.host_framework.end_request(environ)
        return app_iter

#TODO: Wrap to issue deprecation warnings
TGWidgetsMiddleware = ToscaWidgetsMiddleware

def _load_from_entry_point(name):
    for ep in pkg_resources.iter_entry_points('toscawidgets.host_frameworks'):
        if ep.name == name:
            return ep
        
def _extract_args(args, prefix, adapters={}):
    l = len(prefix)
    nop = lambda v: v
    return dict((k[l:], adapters.get(k[l:], nop)(v))
                for k,v in args.iteritems() if k.startswith(prefix))
    
def _load_host_framework(host_framework):
    if ':' not in host_framework:
        ep = _load_from_entry_point(host_framework)
    else:
        ep = pkg_resources.EntryPoint.parse("hf="+host_framework)
    if ep:
        hf = ep.load(False)
    else:
        hf = None
    if not hf:
        raise LookupError("Could not load %s" % host_framework)
    return hf

def make_middleware(app, config=None, host_framework=None):
    config = (config or {}).copy()
    if host_framework is not None:
        import warnings
        warnings.warn("The 'host_framework' parameter is depreated. Plase use "
                      "the tw.framework' key of the config dict for "
                      "the same effect.", DeprecationWarning, 2)
    else:
        host_framework = config.pop('toscawidgets.framework', 'wsgi')
    if isinstance(host_framework, basestring):
        host_framework = _load_host_framework(host_framework)
    middleware_args = _extract_args(config, 'toscawidgets.middleware.', {
        'inject_resources': asbool,
        })
    hf_args = _extract_args(config, 'toscawidgets.framework.')
    return ToscaWidgetsMiddleware(app, host_framework=host_framework(**hf_args),
                                  **middleware_args)
