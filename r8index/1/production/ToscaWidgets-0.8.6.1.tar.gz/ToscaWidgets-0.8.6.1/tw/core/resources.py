import threading, logging, os, string

from itertools import izip, chain, imap

from pkg_resources import resource_filename, working_set, Requirement

import tw
from tw.core.base import Widget
from tw.core.util import Enum, OrderedSet

from dispatch import strategy
from tw.core.genericfunctions import generic, PriorityDisambiguated, \
                                     default_rule

__all__ = [
    "Resource", "Link", "JSLink", "CSSLink", "Source", "JSSource", "CSSSource",
    "locations", "registered_directories", "merge_resources", 
    "retrieve_resources", "JSFunctionCalls", "IECSSLink", "IECSSSource",
    "IEJSLink", "IEJSSource", "JSMixin", "CSSMixin"
    ]

log = logging.getLogger(__name__)


from paste.urlparser import StaticURLParser
from paste.request import path_info_pop

class ResourcesApp(object):
    def __init__(self, prefix='/resources'):
        self._lock = threading.Lock()
        self._dirs = {}
        self.prefix = prefix

    
    def register(self, modname, filename):
        if isinstance(modname, Requirement):
            r_filename = resource_filename(modname, filename)
            modname = os.path.basename(working_set.find(modname).location)
        else:
            r_filename = resource_filename(modname, filename)

        if not os.path.exists(r_filename):
            log.warn("The file '%s' does not exist", r_filename)

        basename = os.path.basename(r_filename)
        dirname = os.path.dirname(r_filename)
        orig_dir_components = os.path.split(filename)[:-1]
        webdir = '/'.join(chain(['', modname], orig_dir_components))

        self._lock.acquire()
        try:
            old_dir = self._dirs.get(webdir)
            if old_dir and old_dir != dirname:
                raise ValueError(
                    "%s is already registered for %s" % (webdir,old_dir)
                    )
            self._dirs[webdir] = dirname
        finally:
            self._lock.release()
        url = '/'.join([self.prefix, webdir.strip('/'), basename])
        return webdir, dirname, url

    def get_prefixed(self):
        return tuple((self.prefix + k, v) for k,v in self)
    
    def __iter__(self):
        # Uses .items in case another thread modifies the dict during iteration
        return iter(self._dirs.items())

    def __call__(self, environ, start_response): 
        path_info = environ.get('PATH_INFO', '')
        for webdir, dirname in self:
            if path_info.startswith(webdir):
                script_name = environ.get('SCRIPT_NAME', '')
                environ['SCRIPT_NAME'] = script_name + webdir
                path_info = environ['PATH_INFO'] = path_info[len(webdir)+1:]
                environ['PATH_INFO'] = path_info
                return StaticURLParser(dirname)(environ, start_response)
        return StaticURLParser('').not_found(environ, start_response)
             

    # Deprecated methods
    def add(self, modname, filename):
        import warnings
        warnings.warn("ResourcesApp.add is deprecated, use 'register' "
                      "instead", DeprecationWarning, 2)
        return self.register(modname, filename)

    def get_all(self, prefix=''):
        import warnings
        warnings.warn("ResourcesApp.get_all is deprecated, use "
                      "'get_prefixed' instead. Note that it no longer supports "
                      "a 'prefix' parameter, use framework.url to append "
                      "correct prefix.", DeprecationWarning, 2)
        return self.get_prefixed()
        

#XXX Support deprecated regisered_directories name
registry = registered_directories = ResourcesApp()

#------------------------------------------------------------------------------
# Base class for all resources
#------------------------------------------------------------------------------

class Resource(Widget):
    """
    A resource for your widget, like a link to external JS/CSS or inline
    source to include at the page the widget is displayed.

    It has the following parameters:

    `location`
        Location on the page where the resource should be placed. Available
        locations can be queried at ``Resource.valid_locations``
    """

    valid_locations = Enum('head', 'bodytop', 'bodybottom')
    location = valid_locations.head

    def add_for_location(self, location):
        return location == self.location

    def inject(self):
        """
        Push this resource into request-local so it is injected to the page
        """
        tw.framework.register_resources(self.retrieve_resources())

locations = Resource.valid_locations

#------------------------------------------------------------------------------
# Utility Mixins
#------------------------------------------------------------------------------

class CSSMixin:
    params = ["media"]
    media = "all"
    
    def post_init(self, *args, **kw):
        self._resources.add(self)


class JSMixin:
    def post_init(self, *args, **kw):
        self._resources.add(self)

class IEMixin:
    params = ["version"]
    version = ''

    _trans_table = ( ('>=',  '>',  '<=',  '<'), ('gte ', 'gt ', 'lte ', 'lt '))

    def _extend_template(self, d):
        d.version = str(d.version)
        for i, s in enumerate(self._trans_table[0]):
            d.version = d.version.replace(s, self._trans_table[1][i])
        s = ('', ' ')[int(bool(d.version))]
        d.template = "<!--[if IE%s${version}]>%s<![endif]-->"%(s,self.template)
    

#------------------------------------------------------------------------------
# Links
#------------------------------------------------------------------------------


class Link(Resource):
    """
    A link to an external resource, like a a JS or CSS file stored in the filesystem.

    Widgets automatically use the framework to register the directory where the resource
    is located so be careful that those directories contains no private data!

    It has the following parameters:

    `modname`
        The module that contains the Widget declaration.
        If not given, it defaults to the name of the module where the Link is 
        declared. Must be an existent module name.
        You can also pass a pkg_resources.Requirement instance to point to the
        root of an egg distribution.

    `filename`
        The relative path (from the module's or distribution's path) of the 
        file the Link should link to.
    """

    params = ['link', 'filename', 'modname']
    _link = None

    def __new__(cls, id=None, parent=None, children=[], **kw):
        if isinstance(parent, basestring):
            raise ValueError(
                "Links no longer support 'modname' and 'filename' as positional"
                " arguments. Provide them as kw args. instead. That would be:\n\n"
                "%s(modname=%r, filename=%r)"%(cls.__name__, id, parent)
                )
        return Resource.__new__(cls,id,parent,children,**kw)

    def __init__(self, *args, **kw):
        super(Link, self).__init__(*args, **kw)
        if self.filename:
            modname = self.modname or self.__module__
            self.webdir, self.dirname, self.link = registry.register(
                modname, self.filename
                )

    def _get_link(self):
        try:
            path = resource_filename(self.modname, self.filename)
            mtime = int(os.path.getmtime(path))
        except (OSError, TypeError):
            # If the resource cannot be located ot the file doesn't exist
            # it might be dynamically generated so generate a dummy mtime
            mtime = 0
        return tw.framework.url(self._link or '') + "?v=%d" % mtime

    def _set_link(self, link):
        self._link = link

    link = property(_get_link, _set_link)

    #XXX: Unused
    #def __hash__(self):
        #return hash(self.modname + self.filename)

    def __eq__(self, other):
        return (
            (getattr(other, "modname", None) == self.modname) and 
            (getattr(other, "filename", None) == self.filename)
            )



class CSSLink(Link,CSSMixin):
    """
    A link to an external CSS file.
    """
    template = """\
<link rel="stylesheet" type="text/css" href="$link" media="$media" />"""


class IECSSLink(CSSLink, IEMixin):
    def update_params(self, d):
        CSSLink.update_params(self, d)
        self._extend_template(d)


class JSLink(Link, JSMixin):
    template = """<script type="text/javascript" src="$link"></script>"""


class IEJSLink(JSLink, IEMixin):
    def update_params(self, d):
        JSLink.update_params(self, d)
        self._extend_template(d)

#------------------------------------------------------------------------------
# Raw source Resources
#------------------------------------------------------------------------------


class Source(Resource):
    """
    An inlined chunk of source code

    It has the following parameters:

    `src`
        A string with the source to include between the resource's tags. Can 
        also be a template for string.Template. Any attribute listed at 
        ``source_vars`` will be fetched from the instance or from the kw args 
        to ``display`` or ``render`` into a dictionary to provide values to 
        fill in.
        
    Examples:
        
        >>> class MySource(Source):
        ...     template = "$src"
        ...     src = "foo=$foo"
        ...     source_vars = ["foo"]
        ...     foo = "bar"
        ...
        >>> s = MySource()
        >>> s.render()
        u'foo=bar'

        >>> s = MySource(foo='zoo')
        >>> s.render()
        u'foo=zoo'

        >>> s.render(foo='foo')
        u'foo=foo'

        The whole source can also be overriden

        >>> s.render(src='foo')
        u'foo'
    """
    params = ["src"]

    def __new__(cls, *args, **kw):
        """Support positional params. (src)"""
        src = None
        parent = None
        if len(args) > 0:
            src = args[0]
        kw.setdefault('src', src or getattr(cls, 'src', None))
        if len(args) > 1:
            parent = args[1]
        return Resource.__new__(cls, None, parent, [], **kw) 

    def update_params(self,d):
        super(Source, self).update_params(d)
        src = d.get('src')
        if src:
            source_vars = dict(
                v for v in [(k, getattr(self,k,None)) for k in self.source_vars]
                )
            source_vars.update(
                v for v in d.iteritems() if v[0] in self.source_vars
                )
            d['src'] = string.Template(src).safe_substitute(**source_vars)


    def __hash__(self):
        return hash(self.src)

    def __eq__(self, other):
        return self.src == getattr(other, "src", None)




class CSSSource(Source, CSSMixin):
    """
    An inlined chunk of CSS source code.
    """
    template = """<style type="text/css" media="$media">$src</style>"""


class IECSSSource(CSSSource, IEMixin):
    def update_params(self, d):
        super(IECSSSource, self).update_params(d)
        self._extend_template(d)


class JSSource(Source, JSMixin):
    """
    An inlined chunk of JS source code.
    """
    template = """<script type="text/javascript">$src</script>"""

class IEJSSource(JSSource, IEMixin):
    def update_params(self, d):
        JSSource.update_params(self, d)
        self._extend_template(d)



class JSFunctionCalls(JSSource):
    params = ["function_calls"]
    location = locations.bodybottom
    function_calls = []
    
    def __init__(self, id=None, parent=None, children=[], **kw):
        super(JSFunctionCalls, self).__init__(id, parent, children, **kw)
        self.src = "\n%s\n" % "\n".join(map(str, self.function_calls))

    

class JSDynamicFunctionCalls(JSFunctionCalls):

    def update_params(self,d):
        super(JSDynamicFunctionCalls,self).update_params(d)
        # Keep in mind self._calls_for_request has calls for *all* widgets
        d.src = "\n%s\n" % "\n".join(
            map(str, chain(self._calls_for_request, d.function_calls))
            )

    # Since our src is generated dynamically base hash and equality on id
    def __hash__(self):
        return id(self)

    def __eq__(self, other):
        return id(self) == id(other)


# Utilities to retrieve resources


def merge_resources(to, from_):
    """
    In-place merge all resources from ``from_`` into ``to``. Resources
    from ``to_`` will come first in each resulting OrderedSet.
    """
    for k in locations:
        from_location = from_.get(k)
        if from_location:
            to.setdefault(k, OrderedSet()).add_all(from_location)
    return to
    
[generic(PriorityDisambiguated)]
def retrieve_resources(obj):
    """Retrieve resources from obj"""

#XXX Rename to retrieve_resources when RD is finally removed
[retrieve_resources.when(default_rule, warn=False)]
def _retrieve_resources(obj):
    ret = {}
    if getattr(obj, 'retrieve_resources', None):
        ret = obj.retrieve_resources()
    elif getattr(obj, 'itervalues', None):
        ret = _retrieve_resources(obj.itervalues())
    elif getattr(obj, '__iter__', None):
        ret = reduce(merge_resources, imap(_retrieve_resources, iter(obj)), {})
    return ret


dynamic_js_calls = JSDynamicFunctionCalls('dynamic_js_calls')
