import inspect
from tw.core.util import pre_post_hooks
from tw.core.genericfunctions import PriorityDisambiguated, generic
from tw.core.exceptions import *


__all__ = [ "WidgetType", "WidgetsListType", "pre_init", "post_init"]

        
class WidgetType(type):
    def __new__(meta,name,bases,dct):
        dct['_cls_children'] = dct.pop('children',_children_from_bases(bases))
        if isinstance(dct.get('params'), dict):
            for param_name, doc in dct['params'].iteritems():
                dct[param_name+'__doc'] = doc
        params = frozenset_from_all_bases(dct,bases,'params')
        frozenset_from_all_bases(dct,bases,'source_vars')
        __init__ = dct.pop('__init__', None)
        if __init__:
            dct['__init__'] = pre_post_hooks(None, 'post_init')(__init__)
        new = type.__new__(meta,name,bases,dct)
        return new


def _children_from_bases(bases):
    for base in bases:
        if hasattr(base, '_cls_children'):
            return base._cls_children
    return []

def frozenset_from_all_bases(clsdct, bases, name):
    _set = set(clsdct.pop(name,[]))
    [_set.update(getattr(b,name)) for b in bases if hasattr(b, name)]
    fs = clsdct[name] = frozenset(_set)
    return fs

    
class DeprecatedGenericHook(object):
    def __init__(self, name):
        self.name = name

    def deprecate(self,*args,**kw):
        raise DeprecationWarning("""
%(name)s is no longer a generic function hook. You can emulate it by declaring 
a method called "%(name)s" in your widget with the same signature as __init__ 
(or a catch-all one) which will be called by a wrapper that wraps __init__. 
You don't need to call the superclasses's method cooperatively as they will 
always be called (emulating before and after hooks)
Hooks' return value will be discarded. Their purpose is to set state in 
self.""" % {'name':self.name})
    when = deprecate
    before = deprecate
    after = deprecate
    around = deprecate

pre_init = DeprecatedGenericHook('pre_init')
post_init = DeprecatedGenericHook('post_init')


[generic()]
def add_lists(self,other):
    pass

[generic()]
def radd_lists(self,other):
    pass




class WidgetsListType(type):
    __add__ = add_lists
    __radd__ = radd_lists

    def __new__(meta,name,bases,dct):
        clones = []
        for id, w in dct.items():
            if hasattr(w,'_serial') and hasattr(w, 'clone'):
                dct.pop(id)
                clones.append((w._serial, id, w.clone) )
        clones.sort()
        def __init__(self, clones=clones): 
            # we instantiate the clones on initialization
            widgets = [w[2](id=w[1]) for w in clones]
            self.extend(widgets)
        dct.update({'__slots__':[], '__init__':__init__})
        return type.__new__(meta,name,bases,dct)
        

if __name__ == "__main__":
    import doctest
    doctest.testmod()
