import inspect
import itertools
import logging
import sys
import warnings
import pkg_resources
pkg_resources.require("RuleDispatch>=0.5a0.dev_r2247")

from dispatch import strategy, functions, generic
from dispatch.interfaces import *
from peak.util.decorators import decorate_assignment, frameinfo, decorate_class


__all__ = [
    "PriorityDisambiguated",
    "default_rule",
    "generic",
    ]

log =  logging.getLogger(__name__)

default_rule = strategy.default

DEPRECATED_MSG = """\
RuleDispatch generic functions are deprecated in ToscaWidget's core. You can
extend TW's functions using PEAK-Rules if needed from client code.
"""

def _prioritized_safe_methods(grouped_cases):
    """Yield all methods in 'grouped_cases' including those in groups with
    more than one case (AmbiguousMethods) in the priority specified by the 
    priority defined when decorating the method.
    Priorities must be distinct within a group of ambiguous methods or else
    an AmbiguousMethod will be raised.
    """
    for group in grouped_cases:
        if len(group) > len(set([meth._priority for sig,meth in group])):
            yield AmbiguousMethod(group)
            break
        elif len(group) > 1:
            for prio,meth in sorted(
                [(meth._priority, meth) for sig,meth in group],
                reverse=True,
                ):
                yield meth
        else:
            yield group[0][1]

def _prioritized_all_methods(grouped_cases):
    """Yield all methods in 'grouped_cases' including those in groups with
    more than one case (AmbiguousMethods) in the priority specified by the 
    priority defined when decorating the method.
    """
    for group in grouped_cases:
        for prio,meth in sorted(
            [(meth._priority, meth) for sig,meth in group],
            reverse=True,
            ):
            yield meth

class PriorityDisambiguated(functions.GenericFunction):
    """Remimplementation of dispatch.functions.GenericFunction allowing
    the case decorators to specify a priority for ordering and disambiguation
    purposes.
    """

    def combine(self,cases):
        """Same as GenericFunction.combine but replaces 
        strategy.safe_methods and strategy.all_methods with priority-ordering
        generators."""
        
        strict = [strategy.ordered_signatures,_prioritized_safe_methods]
        loose  = [strategy.ordered_signatures,_prioritized_all_methods]

        cases = strategy.separate_qualifiers(
            cases,
            around = strict, before = loose, primary = strict, after =loose,
        )

        primary = strategy.method_chain(cases.get('primary',[]))

        if cases.get('after') or cases.get('before'):

            befores = strategy.method_list(cases.get('before',[]))
            afters = strategy.method_list(list(cases.get('after',[]))[::-1])

            def chain(*args,**kw):
                for tmp in befores(*args,**kw): pass  # toss return values
                result = primary(*args,**kw)
                for tmp in afters(*args,**kw): pass  # toss return values
                return result

        else:
            chain = primary

        if cases.get('around'):
            chain = strategy.method_chain(list(cases['around'])+[chain])

        return chain

    def around(self,cond,priority=0, warn=True):
        """Add function as an "around" method w/'cond' as a guard

        If 'cond' is parseable, it will be parsed using the caller's frame
        locals and globals.
        """
        if warn:
            warnings.warn(DEPRECATED_MSG, DeprecationWarning, 2)
        return self._decorate(cond,"around",priority=priority)


    def before(self,cond,priority=0, warn=True):
        """Add function as a "before" method w/'cond' as a guard

        If 'cond' is parseable, it will be parsed using the caller's frame
        locals and globals.
        """
        if warn:
            warnings.warn(DEPRECATED_MSG, DeprecationWarning, 2)
        return self._decorate(cond,"before",priority=priority)


    def after(self,cond,priority=0, warn=True):
        """Add function as an "after" method w/'cond' as a guard

        If 'cond' is parseable, it will be parsed using the caller's frame
        locals and globals.
        """
        if warn:
            warnings.warn(DEPRECATED_MSG, DeprecationWarning, 2)
        return self._decorate(cond,"after",priority=priority)


    def when(self,cond,priority=0, warn=True):
        """Add following function to this GF, w/'cond' as a guard

        If 'cond' is parseable, it will be parsed using the caller's frame
        locals and globals.
        """
        if warn:
            warnings.warn(DEPRECATED_MSG, DeprecationWarning, 2)
        return self._decorate(cond, "primary", priority=priority)

    def _decorate(self,cond,qualifier=None,frame=None,depth=2,priority=0):
        """Analogous to AbstractGeneric._decorate but accepts a priority
        parameter to attach as an attribute to the decorated method to aid
        in disambiguation/ordering."""
        frame = frame or sys._getframe(depth)
        rule = cond
        cond = self.parseRule(cond,frame=frame) or cond

        def registerMethod(frm,name,value,old_locals):
            kind,module,locals_,globals_ = frameinfo(frm)
            if qualifier is None:
                func = value
            else:
                func = qualifier,value

            if kind=='class':
                # 'when()' in class body; defer adding the method
                def registerClassSpecificMethod(cls):
                    req = strategy.Signature(
                        [(strategy.Argument(0),ICriterion(cls))]
                    )
                    self.addMethod(req & cond, func, priority=priority)
                    return cls
        
                decorate_class(registerClassSpecificMethod,frame=frm)
            else:
                self.addMethod(cond,func, priority=priority)
    
            if old_locals.get(name) in (self,self.delegate):
                return self.delegate

            return value

        return decorate_assignment(registerMethod,frame=frame)
    
    def addMethod(self,predicate,function,qualifier=None,priority=0):
        if isinstance(function, tuple):
            function[1]._priority = priority
        else: 
            function._priority = priority
        if qualifier is not None:
            function = qualifier,function
        for signature in IDispatchPredicate(predicate):
            self[signature] = function
