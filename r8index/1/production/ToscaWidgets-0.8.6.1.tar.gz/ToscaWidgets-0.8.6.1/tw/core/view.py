import sys
import logging, re

from pkg_resources import iter_entry_points, load_entry_point

import tw
from tw.core.genericfunctions import generic, PriorityDisambiguated,\
                                     default_rule
from tw.core.exceptions import WidgetException


__all__ = ["EngineManager", "Renderable", "display", "render"]


log = logging.getLogger(__name__)


class EngineException(WidgetException):
    pass

class EngineManager(dict):
    """
    Manages availble templating engines.
    """
    default_view = 'toscawidgets'
    _cache = {}

    def __init__(self, extra_vars_func=None, options=None, load_all=True):
        self.extra_vars_func = extra_vars_func
        self.options = options
        if load_all:
            self.load_all()
            

    def __repr__(self):
        return "< %s >" % self.__class__.__name__

    def load_engine_from_distribution(self, dist, name, engine_options=None,
                                      stdvars=None):
        import warnings
        warnings.warn("This method is deprecated, used load_engine(name, "
                      "engine_options, stdvars, distribution) instead.",
                      DeprecationWarning, 2)
        self.load_engine(name, engine_options, stdvars, dist)


    def load_engine(self, name, options=None, extra_vars_func=None, 
                    distribution=None):
        factory = None
        if distribution:
            factory = load_entry_point(
                distribution, "python.templating.engines", name)
        else:
            for entrypoint in iter_entry_points("python.templating.engines"):
                if entrypoint.name == name:
                    factory = entrypoint.load()

        if factory is None:
            raise EngineException("No plugin available for engine '%s'" % name)

        options = options or self.options or {}
        options = options.copy()
        # emulate Kid and Genshi's dotted-path notation lookup
        options.setdefault('mako.directories', []).extend(sys.path)
        # make sure mako produces utf-8 output so we can decode it and use
        # unicode internally
        options['mako.output_encoding'] = 'utf-8'
        extra_vars_func = extra_vars_func or self.extra_vars_func

        # Check for deprecated use.
        if hasattr(self, '_initialize_engine'):
            import warnings
            warnings.warn("_initialize_engine is deprecated. If you're overriding "
                          "it you shouldn't (its private anyway ;) "
                          "You'll probably be doing it to provide an "
                          "extra_vars_func, you can now do that by passing it "
                          "when instantiating the EngineManager instead. "
                          "This method will no longer be called on the stable "
                          "release.", DeprecationWarning, 1)
            self._initialize_engine(name, factory, options, extra_vars_func)
            return
        try:
            self[name] = factory(extra_vars_func, options)
        except:
            # Some engine's will fail to accept turbogears.config non-dict-like
            # config object
            log.error("Failed to initialize %r", factory)



    def load_all(self, engine_options=None, stdvars=None):
        for ep in iter_entry_points("python.templating.engines"):
            try:
                self.load_engine(ep.name, engine_options, stdvars)
            except Exception, e:
                log.warn("Failed to load '%s' template engine: %s", ep.name, e)


    def load_template(self, template, engine_name):
        """Return's a compiled template and it's enginename"""
        output = None
        if isinstance(template, basestring) and _is_inline_template(template):
            # Assume inline template, try to fetch from cache
            key = (template, engine_name)
            try:
                output = self._cache[key]
                #log.debug("Cache hit for: %s", `key`)
            except KeyError:
                #log.debug("Cache miss for: %s", `key`)
                output = self._cache[key] = self[engine_name].load_template(
                    None, template_string = template
                    )
        elif isinstance(template, basestring):
            # Assume template path
            output = self[engine_name].load_template(template)
        else:
            # Assume compiled template
            output = template
        return output

    [generic(PriorityDisambiguated)]
    def display(self, renderable, **kw):
        """
        Displays the renderable. Returns appropiate output for target template
        engine
        """

    [generic(PriorityDisambiguated)]
    def render(self, renderable, **kw):
        """
        Returns the serialized output in a string.
        Useful for debugging or to return to the browser as-is.
        """ 

    def get_render_method(self, origin, destination, method):
        engine = self[origin]
        # Only pass-through Element/Stream output if rendering on the same
        # template engine as the one producing output
        if method == 'display' and \
          origin == destination and origin in ['kid', 'genshi']:
            return engine.transform
        # In any other case render as a string
        def _render_xhtml(**kw):
            kw.update(format='xhtml')
            return engine.render(**kw)
        return _render_xhtml


    def adapt_output(self, output, destination):
        # Handle rendering strings on Genshi so they're not escaped
        if isinstance(output, basestring) and destination == 'genshi':
            from genshi.input import HTML
            output = HTML(output)
        # Handle rendering strings on Kid so they're not escaped
        elif isinstance(output, basestring) and destination == 'kid':
            from kid import XML
            output = XML(output)
        return output
    

display = EngineManager.display.im_func
render = EngineManager.render.im_func

#TODO: Move this inside EngineManager once RuleDispatch is finally removed
def make_renderer(method):
    def _renderer(self, renderable, **kw):
        template = kw.pop('template', renderable.template)
        if template is None:
            return
        origin = kw.get('engine_name', renderable.engine_name)
        destination = kw.get('displays_on', renderable.displays_on)
        if origin != 'cheetah':
            template = self.load_template(template, origin)
        renderer = self.get_render_method(origin, destination, method)
        output = renderer(info=kw, template=template)
        if method == 'display':
            output = self.adapt_output(output, destination)
        # Make sure string output is always unicode
        if isinstance(output, str):
            output = unicode(output, 'utf-8')
        return output
    return _renderer

render.when(default_rule, warn=False)(make_renderer('render'))
display.when(default_rule, warn=False)(make_renderer('display'))


def choose_engine(tpl, engine_name=None):
    if isinstance(tpl, basestring) and not _is_inline_template(tpl):
        colon = tpl.find(":")
        if colon > -1:
            engine_name = tpl[:colon]
            tpl = tpl[colon+1:]
    return engine_name, tpl

    
_is_inline_template = re.compile(r'(<|\n|\$)').search



class Renderable(object):
    """Base class for all objects that the EngineManager can render"""

    engine_name = "toscawidgets"
    displays_on = "toscawidgets"
    template = None

    def __new__(cls, *args, **kw):
        obj = object.__new__(cls, *args, **kw)
        obj.template = kw.pop("template", obj.template)
        engine_name = kw.pop("engine_name", None)
        if obj.template is not None:
            engine_name, obj.template = choose_engine(obj.template)
        if engine_name:
            obj.engine_name = engine_name
        return obj

    def render(self, **kw):
        return tw.framework.engines.render(self, **kw)

    def display(self, **kw):
        return tw.framework.engines.display(self, **kw)
