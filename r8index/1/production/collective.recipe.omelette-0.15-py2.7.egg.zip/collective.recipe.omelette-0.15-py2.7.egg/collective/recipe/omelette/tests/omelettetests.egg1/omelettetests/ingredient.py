"""Namespace packages can contain modules.  This is one such module."""
