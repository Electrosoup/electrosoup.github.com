:mod:`repoze.zodbconn`
======================

A library which allows ZODB databases to be constructed from URI
specifications, and other various utilities and helpers dealing with
using ZODB databases from applications.

.. toctree::
   :maxdepth: 2

   narr
   changes

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
