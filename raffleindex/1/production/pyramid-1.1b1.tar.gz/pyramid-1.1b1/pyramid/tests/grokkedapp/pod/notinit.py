from pyramid.view import view_config

@view_config(name='pod_notinit')
def subpackage_notinit(context, request):
    return 'pod_notinit'
