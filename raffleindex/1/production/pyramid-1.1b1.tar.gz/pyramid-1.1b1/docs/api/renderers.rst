.. _renderers_module:

:mod:`pyramid.renderers`
---------------------------

.. module:: pyramid.renderers

.. autofunction:: get_renderer

.. autofunction:: render

.. autofunction:: render_to_response

.. autoclass:: JSONP

