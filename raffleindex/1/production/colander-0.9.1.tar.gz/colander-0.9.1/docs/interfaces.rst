Interfaces
----------

.. automodule:: colander.interfaces

  .. autofunction:: Validator

  .. autoclass:: Type
     :members:

