Colander
========

An extensible package which can be used to:

- deserialize and validate a data structure composed of strings,
  mappings, and lists.

- serialize an arbitrary data structure to a data structure composed
  of strings, mappings, and lists.

Please see `http://docs.repoze.org/colander
<http://docs.repoze.org/colander>`_ for further documentation.
