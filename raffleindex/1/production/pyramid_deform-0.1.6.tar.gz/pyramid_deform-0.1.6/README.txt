pyramid_deform
==============

``pyramid_deform`` provides bindings for the Pyramid web framework to the
`Deform <http://docs.repoze.org/deform>`_ form library.

For more information, see `the Pylons Project website
<http://docs.pylonshq.com>`_.



