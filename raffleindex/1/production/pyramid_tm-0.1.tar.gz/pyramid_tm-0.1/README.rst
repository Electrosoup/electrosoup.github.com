``pyramid_tm``
==============

``pyramid_tm`` is a package which allows Pyramid requests to join
the active transaction as provided by the `transaction
<http://pypi.python.org/pypi/transaction>`_ package.

See `http://docs.pylonsproject.org/projects/pyramid_tm/dev/
<http://docs.pylonsproject.org/projects/pyramid_tm/dev/>`_ 
or ``docs/index.rst`` in this distribution for detailed
documentation.
