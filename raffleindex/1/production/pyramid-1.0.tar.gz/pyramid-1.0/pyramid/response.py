from webob import Response
Response = Response # pyflakes
