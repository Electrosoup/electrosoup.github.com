.. _paster_module:

:mod:`pyramid.paster`
---------------------------

.. module:: pyramid.paster

.. function:: get_app(config_file, name)

    Return the WSGI application named ``name`` in the PasteDeploy
    config file ``config_file``.

     
