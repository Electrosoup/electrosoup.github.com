from zope.index.text.textindex import TextIndex
