:mod:`repoze.catalog` Change History
====================================

.. literalinclude:: ../CHANGES.txt
