``pyramid_zodbconn``
====================

A package which provides integration between `ZODB <http://zodb.org>`_ and
a Pyramid application.

See the documentation at
https://docs.pylonsproject.org/projects/pyramid_zodbconn/dev/ for more
information.
