from translationstring import TranslationStringFactory
_ = TranslationStringFactory('deform')

