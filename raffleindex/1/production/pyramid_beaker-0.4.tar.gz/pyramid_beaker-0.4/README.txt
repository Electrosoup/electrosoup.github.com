pyramid_beaker
==============

Provides a session factory for the `Pyramid <http://docs.pylonshq.com>`_ web
framework backed by the `Beaker <http://beaker.groovie.org/>`_ sessioning
system.

See `the Pylons Project documentation <http://docs.pylonshq.com>`_ for more
information.
