API Documentation 
-----------------

.. automodule:: pyramid_beaker

.. autofunction:: set_cache_regions_from_settings

.. autofunction:: session_factory_from_settings

.. autofunction:: BeakerSessionFactoryConfig

