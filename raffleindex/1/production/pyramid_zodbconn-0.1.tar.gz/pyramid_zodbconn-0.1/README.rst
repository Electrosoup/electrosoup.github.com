``pyramid_zodbconn``
====================

A package which provides integration between `ZODB <http://zodb.org>`_ and
a Pyramid application.

See the documentation at
https://docs.pylonsproject.org/projects/pyramid_zodbconn/dev/ for more
information.

This package currently will not work with any released Pyramid; it requires
the Pyramid trunk (aka "1.2dev"), available from
https://github.com/Pylons/pyramid .
